t = document.querySelector(".propiedades")
let html = ""
for (let valores of propiedadesJSON) {
        html += `
    <div class="propiedades">
        <div class="propiedad">
            <div class="img" style="background-image: url('${valores.src}')"></div>
            <section>
                <h5>${valores.name}</h5>
                <div class="d-flex justify-content-between">
                    <p>Cuartos: ${valores.rooms}</p>
                    <p>Metros: ${valores.m}</p>
                </div>
                <p class="my-3">${valores.description}</p>
                <button class="btn btn-info ">Ver más</button>
            </section>
        </div>
    </div>
  </section>
  `}
    t.innerHTML = html;
         
function calcular() {
    let cuartos = document.querySelector("#cuarto").value;
    let metrosDesde = document.querySelector("#metro1").value;
    let metrosHasta = document.querySelector("#metro2").value;
    let total = document.querySelector('#total');
    cuenta = 0
    if (cuartos == ""||metrosDesde == ""||metrosHasta == "") {
      alert("Llene todos los campos por favor");
    }
    let html = ""
    for (let valores of propiedadesJSON) {
      if (cuartos <= valores.rooms&&metrosDesde <= valores.m&&metrosHasta >= valores.m) {
        cuenta = cuenta + 1
        html += `
    <div class="propiedades">
        <div class="propiedad">
            <div class="img" style="background-image: url('${valores.src}')"></div>
            <section>
                <h5>${valores.name}</h5>
                <div class="d-flex justify-content-between">
                    <p>Cuartos: ${valores.rooms}</p>
                    <p>Metros: ${valores.m}</p>
                </div>
                <p class="my-3">${valores.description}</p>
                <button class="btn btn-info ">Ver más</button>
            </section>
        </div>
    </div>
  </section>
  `}
      const t = document.querySelector(".propiedades");
      t.innerHTML = html;
      total.innerHTML = cuenta
    }
  };
  button = document.querySelector("#button")
  button.addEventListener("click", calcular);
  